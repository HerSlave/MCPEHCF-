<?php

namespace hcf\area;

use Exception;

class AreaException extends Exception {

}