<?php

namespace hcf\discord;

use hcf\HCF;
use hcf\HCFPlayer;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use CortexPE\DiscordWebhookAPI\Message;
use CortexPE\DiscordWebhookAPI\Webhook;
use CortexPE\DiscordWebhookAPI\Embed;
use pocketmine\event\player\PlayerQuitEvent;

class Logger implements Listener {

    private $core;

    public function __construct(HCF $core){
        $this->core = $core;
    }

    public function onJoin(PlayerJoinEvent $event){
        $player = $event->getPlayer();
        if($player instanceof HCFPlayer){
            $webHook = new Webhook("https://discordapp.com/api/webhooks/721247950835286087/cpnL-G_D2k1O5Suz15ubRkS34TW5Ihqlud-KDuiJlb1aKe4TkXqQXIj0FqrdAju8U-ZL");
            $msg = new Message();
            $embed = new Embed();
            $embed->setTitle("ValetHCF | Logger");
            $embed->setColor(0x00FF00);
            $embed->setDescription($player->getName() . " has joined the server\n" . $player->getName() . " Info:\n\nLives: " . $player->getLives() . "\nFaction: " . $player->getFaction() . "\nFacRole: " . $player->getFactionRole() . "\nKills: " . $player->getKills() . "\nBalance: " . $player->getBalance() . "\n\n__ValetHCF__");
            $msg->addEmbed($embed);
            $webHook->send($msg);
        }
    }

    public function onLeft(PlayerQuitEvent $event){
        $player = $event->getPlayer();
        if($player instanceof HCFPlayer){
            $webHook = new Webhook("https://discordapp.com/api/webhooks/721247950835286087/cpnL-G_D2k1O5Suz15ubRkS34TW5Ihqlud-KDuiJlb1aKe4TkXqQXIj0FqrdAju8U-ZL");
            $msg = new Message();
            $embed = new Embed();
            $embed->setTitle("ValetHCF | Logger");
            $embed->setColor(0x00FF00);
            $embed->setDescription($player->getName() . " has left the server.");
            $msg->addEmbed($embed);
            $webHook->send($msg);
        }
    }
}