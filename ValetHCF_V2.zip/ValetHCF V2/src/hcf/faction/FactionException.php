<?php

namespace hcf\faction;

use Exception;

class FactionException extends Exception {

}