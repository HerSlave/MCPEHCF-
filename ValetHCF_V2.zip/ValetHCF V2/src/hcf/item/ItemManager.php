<?php

namespace hcf\item;

use hcf\HCF;
use hcf\item\entity\GrapplingHook;
use hcf\item\types\GlassBottle;
use hcf\item\types\SplashPotion;
use hcf\item\types\TeleportationBall;
use pocketmine\entity\Entity;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\item\enchantment\ProtectionEnchantment;
use pocketmine\item\enchantment\SharpnessEnchantment;
use pocketmine\item\GoldBoots;
use pocketmine\item\GoldChestplate;
use pocketmine\item\GoldHelmet;
use pocketmine\item\GoldLeggings;
use pocketmine\item\ItemFactory;

class ItemManager {

    /** @var HCF */
    private $core;

    /**
     * ItemManager constructor.
     *
     * @param HCF $core
     */
    public function __construct(HCF $core) {
        $this->core = $core;
        $core->getServer()->getPluginManager()->registerEvents(new ItemListener($core), $core);
        $this->init();
    }

    public function init() {
        Enchantment::registerEnchantment(new Enchantment(Enchantment::LOOTING, "Looting", Enchantment::RARITY_UNCOMMON, Enchantment::SLOT_SWORD, Enchantment::SLOT_NONE, 3));
        Enchantment::registerEnchantment(new Enchantment(Enchantment::FORTUNE, "Fortune", Enchantment::RARITY_UNCOMMON, Enchantment::SLOT_DIG, Enchantment::SLOT_NONE, 3));
        Enchantment::registerEnchantment(new Enchantment(Enchantment::POWER, "%enchantment.arrowDamage", Enchantment::RARITY_COMMON, Enchantment::SLOT_BOW, Enchantment::SLOT_NONE, HCF::MAX_POWER));
        Enchantment::registerEnchantment(new ProtectionEnchantment(Enchantment::PROTECTION, "%enchantment.protect.all", Enchantment::RARITY_COMMON, Enchantment::SLOT_ARMOR, Enchantment::SLOT_NONE, HCF::MAX_PROTECTION, 0.75, null));
        Enchantment::registerEnchantment(new SharpnessEnchantment(Enchantment::SHARPNESS, "%enchantment.damage.all", Enchantment::RARITY_COMMON, Enchantment::SLOT_SWORD, Enchantment::SLOT_AXE, HCF::MAX_SHARPNESS));
        ItemFactory::registerItem(
            new class extends GoldHelmet {

                /**
                 * @return int
                 */
                public function getMaxDurability(): int {
                    return parent::getMaxDurability() * 2;
                }
            }, true
        );
        ItemFactory::registerItem(
            new class extends GoldChestplate {

                /**
                 * @return int
                 */
                public function getMaxDurability(): int {
                    return parent::getMaxDurability() * 2;
                }
            }, true
        );
        ItemFactory::registerItem(
            new class extends GoldLeggings {

                /**
                 * @return int
                 */
                public function getMaxDurability(): int {
                    return parent::getMaxDurability() * 2;
                }
            }, true
        );
        ItemFactory::registerItem(
            new class extends GoldBoots {

                /**
                 * @return int
                 */
                public function getMaxDurability(): int {
                    return parent::getMaxDurability() * 2;
                }
            }, true
        );
        ItemFactory::registerItem(new types\GrapplingHook(), true);
        ItemFactory::registerItem(new TeleportationBall(), true);
        ItemFactory::registerItem(new SplashPotion(), true);
        ItemFactory::registerItem(new GlassBottle(), true);
        Entity::registerEntity(\hcf\item\entity\TeleportationBall::class, true);
        Entity::registerEntity(GrapplingHook::class);
    }
}