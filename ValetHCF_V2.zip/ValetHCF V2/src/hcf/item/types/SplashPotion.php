<?php

namespace hcf\item\types;

use pocketmine\block\Block;
use pocketmine\entity\Entity;
use pocketmine\entity\projectile\Projectile;
use pocketmine\event\entity\ProjectileLaunchEvent;
use pocketmine\math\Vector3;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\network\mcpe\protocol\LevelSoundEventPacket;
use pocketmine\Player;
use ReflectionException;

class SplashPotion extends \pocketmine\item\SplashPotion {

    /**
     * SplashPotion constructor.
     *
     * @param int $meta
     */
    public function __construct(int $meta = 0) {
        parent::__construct($meta);
    }

    /**
     * @return int
     */
    public function getMaxStackSize(): int {
        return 1;
    }

    /**
     * @return string
     */
    public function getProjectileEntityType(): string {
        return "ThrownPotion";
    }

    /**
     * @return float
     */
    public function getThrowForce(): float {
        return 0.5;
    }

    /**
     * @param CompoundTag $tag
     */
    protected function addExtraTags(CompoundTag $tag): void {
        $tag->setShort("PotionId", $this->meta);
    }

    /**
     * @param Player $player
     * @param Vector3 $directionVector
     *
     * @return bool
     * @throws ReflectionException
     */
    public function onClickAir(Player $player, Vector3 $directionVector): bool {
        $nbt = Entity::createBaseNBT($player->add(0, $player->getEyeHeight(), 0), $directionVector, $player->yaw, $player->pitch);
        $this->addExtraTags($nbt);
        $projectile = Entity::createEntity($this->getProjectileEntityType(), $player->getLevel(), $nbt, $player);
        if($projectile !== null) {
            $projectile->setMotion($projectile->getMotion()->multiply($this->getThrowForce()));
        }
        $this->count--;
        if($projectile instanceof Projectile) {
            $projectileEv = new ProjectileLaunchEvent($projectile);
            $projectileEv->call();
            if($projectileEv->isCancelled()) {
                $projectile->flagForDespawn();
            }
            else {
                $projectile->spawnToAll();
                $player->getLevel()->broadcastLevelSoundEvent($player, LevelSoundEventPacket::SOUND_THROW, 0, Entity::PLAYER);
            }
        }
        elseif($projectile !== null) {
            $projectile->spawnToAll();
        }
        else {
            return false;
        }
        return true;
    }

    /**
     * @param Player $player
     * @param Block $blockReplace
     * @param Block $blockClicked
     * @param int $face
     * @param Vector3 $clickVector
     *
     * @return bool
     * @throws ReflectionException
     */
    public function onActivate(Player $player, Block $blockReplace, Block $blockClicked, int $face, Vector3 $clickVector): bool {
        $nbt = Entity::createBaseNBT($player->add(0, $player->getEyeHeight(), 0), $player->getDirectionVector(), $player->yaw, $player->pitch);
        $this->addExtraTags($nbt);
        $projectile = Entity::createEntity($this->getProjectileEntityType(), $player->getLevel(), $nbt, $player);
        if($projectile !== null) {
            $projectile->setMotion($projectile->getMotion()->multiply($this->getThrowForce()));
        }
        $this->count--;
        if($projectile instanceof Projectile) {
            $projectileEv = new ProjectileLaunchEvent($projectile);
            $projectileEv->call();
            if($projectileEv->isCancelled()) {
                $projectile->flagForDespawn();
            }
            else {
                $projectile->spawnToAll();
                $player->getLevel()->broadcastLevelSoundEvent($player, LevelSoundEventPacket::SOUND_THROW, 0, Entity::PLAYER);
            }
        }
        elseif($projectile !== null) {
            $projectile->spawnToAll();
        }
        else {
            return false;
        }
        return true;
    }
}