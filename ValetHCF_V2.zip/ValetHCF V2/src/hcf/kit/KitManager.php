<?php

namespace hcf\kit;

use hcf\HCF;
use hcf\kit\types\ArcherKit;
use hcf\kit\types\BardKit;
use hcf\kit\types\BuilderKit;
use hcf\kit\types\DiamondKit;
use hcf\kit\types\FoodKit;
use hcf\kit\types\GrandKit;
use hcf\kit\types\JuniorKit;
use hcf\kit\types\MinerKit;
use hcf\kit\types\PrimalKit;
use hcf\kit\types\PrimeKit;
use hcf\kit\types\RogueKit;
use hcf\kit\types\StarterKIt;

class KitManager {

    /** @var HCF */
    private $core;

    /** @var Kit[] */
    private $kits;

    /**
     * KitManager constructor.
     *
     * @param HCF $core
     */
    public function __construct(HCF $core) {
        $this->core = $core;
        $core->getServer()->getPluginManager()->registerEvents(new KitListener($core), $core);
        $this->init();
    }

    public function init(): void {
        $this->registerKit(new FoodKit());
        $this->registerKit(new StarterKIt());
        $this->registerKit(new JuniorKit());
        $this->registerKit(new GrandKit());
        $this->registerKit(new PrimeKit());
        $this->registerKit(new PrimalKit());
        $this->registerKit(new ArcherKit());
        $this->registerKit(new BardKit());
        $this->registerKit(new BuilderKit());
        $this->registerKit(new MinerKit());
        $this->registerKit(new RogueKit());
        $this->registerKit(new DiamondKit());
    }

    /**
     * @param Kit $kit
     */
    public function registerKit(Kit $kit) {
        $this->kits[$kit->getName()] = $kit;
    }

    /**
     * @param string $name
     *
     * @return Kit|null
     */
    public function getKitByName(string $name): ?Kit {
        return $this->kits[$name] ?? null;
    }

    /**
     * @return Kit[]
     */
    public function getKits(): array {
        return $this->kits;
    }
}