<?php

namespace hcf\koth;

use Exception;

class KOTHException extends Exception {

}