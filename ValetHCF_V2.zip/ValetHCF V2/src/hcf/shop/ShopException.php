<?php

namespace hcf\shop;

use Exception;

class ShopException extends Exception {

}