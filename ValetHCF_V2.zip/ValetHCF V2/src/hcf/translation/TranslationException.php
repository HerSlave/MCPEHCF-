<?php

namespace hcf\translation;

use Exception;

class TranslationException extends Exception {

}