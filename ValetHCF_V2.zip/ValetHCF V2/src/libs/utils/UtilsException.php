<?php

namespace libs\utils;

use Exception;

class UtilsException extends Exception {

}